#include "cyhal.h"
#include "cybsp.h"
#include "cy_retarget_io.h"
#include <FreeRTOS.h>
#include <task.h>
#include "cy_wcm.h"
#include "firebase_client.h"

/* App-init in taak: WCM init -> Firebase client starten */
static void app_task(void *arg)
{
    (void)arg;
    printf("app_task: start\r\n");

    cy_wcm_config_t wcm_cfg = { .interface = CY_WCM_INTERFACE_TYPE_STA };
    cy_rslt_t r = cy_wcm_init(&wcm_cfg);
    printf("app_task: cy_wcm_init -> 0x%08lx\r\n", (unsigned long)r);
    if (r != CY_RSLT_SUCCESS) {
        printf("app_task: WCM init failed, stop.\r\n");
        vTaskSuspend(NULL);
    }

    r = firebase_client_start();
    printf("app_task: firebase_client_start -> 0x%08lx\r\n", (unsigned long)r);
    if (r != CY_RSLT_SUCCESS) {
        printf("app_task: firebase_client_start failed, stop.\r\n");
        vTaskSuspend(NULL);
    }

    printf("app_task: done\r\n");
    vTaskSuspend(NULL); /* klaar */
}

int main(void)
{
    cy_rslt_t result = cybsp_init();
    if (result != CY_RSLT_SUCCESS) { CY_ASSERT(0); }

    __enable_irq();

    /* UART voor logging */
    cy_retarget_io_init(CYBSP_DEBUG_UART_TX, CYBSP_DEBUG_UART_RX, CY_RETARGET_IO_BAUDRATE);
    /* Belangrijk: print direct, niet bufferen */
    setvbuf(stdout, NULL, _IONBF, 0);

    /* Optioneel: LED init */
    cyhal_gpio_init(CYBSP_USER_LED, CYHAL_GPIO_DIR_BIDIRECTIONAL,
                    CYHAL_GPIO_DRIVE_STRONG, CYBSP_LED_STATE_OFF);

    /* Banner */
    printf("===================================\r\n");
    printf("Firebase HTTPS Client\r\n");
    printf("===================================\r\n");

    /* Start app-init task, dan meteen scheduler */
    xTaskCreate(app_task,  "app",  4096, NULL, tskIDLE_PRIORITY + 2, NULL);

    vTaskStartScheduler();
    CY_ASSERT(0);
}
