#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "cy_result.h"

#ifdef __cplusplus
extern "C" {
#endif

void     rtc_time_init(void);
bool     rtc_time_is_set(void);
void     rtc_time_set_epoch(uint32_t epoch);
uint32_t rtc_time_get_epoch(void);

/* UTC (eindigt met 'Z') */
void     rtc_time_format_iso8601(char *buf, uint32_t epoch);

/* CET/CEST automatisch (Europa), expliciete offset +01:00/+02:00 */
void     rtc_time_format_iso8601_local(char *buf, uint32_t epoch);

/* Handig om mee te sturen naar Firebase (offset in minuten, bv. 60 of 120) */
int      rtc_time_local_offset_minutes(uint32_t epoch);

/* SNTP one-shot */
cy_rslt_t rtc_time_sync_sntp(const char *server, uint32_t timeout_ms);

#ifdef __cplusplus
}
#endif
