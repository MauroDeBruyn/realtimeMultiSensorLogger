// source/led_status/led_status.c
#include "led_status.h"

#if defined(CYBSP_LED_STATE_ON)
/* MTB BSP geeft aan of leds active-low zijn */
  #define LED_ON   (CYBSP_LED_STATE_ON)
  #define LED_OFF  (!CYBSP_LED_STATE_ON)
#else
/* Veilige default: active-low (meeste Cypress boards) */
  #define LED_ON   (0)
  #define LED_OFF  (1)
#endif

static bool s_inited = false;

void led_status_init(void)
{
    if (s_inited) return;
    /* Init als OUTPUT, zet beide uit */
    cyhal_gpio_init(P1_5, CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, LED_OFF);
    cyhal_gpio_init(P13_7,   CYHAL_GPIO_DIR_OUTPUT, CYHAL_GPIO_DRIVE_STRONG, LED_OFF);
    s_inited = true;
}

void led_status_set_connected(bool connected)
{
    if (!s_inited) led_status_init();
    if (connected) {
        cyhal_gpio_write(P1_5, LED_ON);
        cyhal_gpio_write(P13_7,   LED_OFF);
    } else {
        cyhal_gpio_write(P1_5, LED_OFF);
        cyhal_gpio_write(P13_7,   LED_ON);
    }
}
