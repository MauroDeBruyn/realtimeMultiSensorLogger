#ifndef FIREBASE_CLIENT_H
#define FIREBASE_CLIENT_H

#include "cy_result.h"
#include <stddef.h>
#include <stdint.h>
#include <stdbool.h>

/* Called once during startup (creates task). */
cy_rslt_t firebase_client_start(void);

cy_rslt_t firebase_send_json(const char *json, size_t len);

#endif /* FIREBASE_CLIENT_H */
