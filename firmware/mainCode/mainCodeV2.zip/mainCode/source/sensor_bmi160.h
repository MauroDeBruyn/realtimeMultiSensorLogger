#ifndef SENSOR_BMI160_H
#define SENSOR_BMI160_H

#include <stdint.h>
#include <stddef.h>
#include "cy_result.h"

/* I2C pin-config (override indien nodig via -D of vóór include) */
#ifndef BMI160_I2C_SDA_PIN
#define BMI160_I2C_SDA_PIN   P6_1
#endif
#ifndef BMI160_I2C_SCL_PIN
#define BMI160_I2C_SCL_PIN   P6_0
#endif

/* BMI160 7-bit adres (0x68 standaard; 0x69 als SDO aan VDD) */
#ifndef BMI160_I2C_ADDR
#define BMI160_I2C_ADDR      (0x68)
#endif

typedef struct {
    float ax, ay, az;   /* g  */
    float gx, gy, gz;   /* dps */
} bmi160_sample_t;

/* Initialiseer I2C + BMI160 (soft reset, powers, ranges) */
cy_rslt_t bmi160_init(void);

/* Lees 1 sample en zet om naar g / dps */
cy_rslt_t bmi160_read(bmi160_sample_t *out);

/* Handige helper om JSON te maken van een sample */
void bmi160_to_json(char *dst, size_t dst_len, const bmi160_sample_t *s);

#endif /* SENSOR_BMI160_H */
