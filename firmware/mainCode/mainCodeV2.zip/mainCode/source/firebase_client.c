/*
 * firebase_client.c
 *
 * HTTPS client voor het posten van JSON naar Firebase
 * (PSoC 6 + FreeRTOS + WCM + Secure Sockets).
 * Met RTC (SNTP) en BMI160 integratie.
 * --> Logt alleen lokale tijd (CET/CEST) in ts_iso.
 */

#include "firebase_client.h"

#include "cy_secure_sockets.h"
#include "cy_tls.h"
#include "cy_wcm.h"
#include "cy_wcm_error.h"
#include "cy_retarget_io.h"

#include "sensor_bmi160.h"      /* BMI160 module */
#include "rtc_time.h"           /* RTC + SNTP */
#include "secure_keys.h"        /* FIREBASE_ROOT_CA_PEM */
#include "led_status.h"

#include <string.h>
#include <stdio.h>
#include <stdbool.h>

#include <FreeRTOS.h>
#include <task.h>
#include <semphr.h>

#ifndef APP_INFO
#define APP_INFO(x)  do { printf x; } while(0)
#endif
#ifndef ERR_INFO
#define ERR_INFO(x)  do { printf x; } while(0)
#endif

/* ---------- Wi-Fi config (override via -D) ---------- */
#ifndef WIFI_SSID
#define WIFI_SSID           "OnePlus12R"
#endif
#ifndef WIFI_PASSWORD
#define WIFI_PASSWORD       "OnePlus12R"
#endif
#ifndef WIFI_SECURITY_TYPE
#define WIFI_SECURITY_TYPE  CY_WCM_SECURITY_WPA2_AES_PSK
#endif
#ifndef MAX_WIFI_RETRY_COUNT
#define MAX_WIFI_RETRY_COUNT 5
#endif

/* ---------- TLS Root CA: init-once ---------- */
static bool s_ca_loaded = false;
static cy_rslt_t tls_ca_init_once(void)
{
    if (s_ca_loaded) return CY_RSLT_SUCCESS;
    cy_rslt_t r = cy_tls_load_global_root_ca_certificates(
                      FIREBASE_ROOT_CA_PEM,
                      strlen(FIREBASE_ROOT_CA_PEM));
    if (r == CY_RSLT_SUCCESS) s_ca_loaded = true;
    return r;
}

/* ---------- Wi-Fi ready-flag o.b.v. events ---------- */
static volatile bool s_wifi_ready = false;

/* Event callback voor WCM: update LED en vlag direct op connect/disconnect/IP
 * (Let op: WCM v2.3.0 gebruikt callback type zonder user_data) */
static void wcm_event_cb(cy_wcm_event_t event, cy_wcm_event_data_t *event_data)
{
    (void)event_data;
    switch (event)
    {
        case CY_WCM_EVENT_CONNECTED:
            APP_INFO(("WCM: CONNECTED (waiting for IP)\n"));
            break;

        case CY_WCM_EVENT_IP_CHANGED:
            s_wifi_ready = true;
            led_status_set_connected(true);   /* Groen */
            APP_INFO(("WCM: IP_CHANGED -> ready\n"));
            break;

        case CY_WCM_EVENT_RECONNECTED:
            APP_INFO(("WCM: RECONNECTED\n"));
            break;

        case CY_WCM_EVENT_CONNECT_FAILED:
            s_wifi_ready = false;
            led_status_set_connected(false);  /* Rood */
            ERR_INFO(("WCM: CONNECT_FAILED\n"));
            break;

        case CY_WCM_EVENT_DISCONNECTED:
            s_wifi_ready = false;
            led_status_set_connected(false);  /* Rood */
            ERR_INFO(("WCM: DISCONNECTED\n"));
            break;

        default:
            break;
    }
}

/* Helper die huidige vlag teruggeeft (i.p.v. ad-hoc IP poll) */
static bool wifi_is_up(void)
{
    return s_wifi_ready;
}

/* ---------- Firebase config (override via -D) ---------- */
#ifndef FIREBASE_HOST
#define FIREBASE_HOST          "psoc6-logger-default-rtdb.europe-west1.firebasedatabase.app"
#endif
#ifndef FIREBASE_PORT
#define FIREBASE_PORT          443
#endif
#ifndef FIREBASE_PATH
#define FIREBASE_PATH          "/sensor/data.json"   /* POST voor auto-ID */
#endif
#ifndef FIREBASE_QUERYSTRING
#define FIREBASE_QUERYSTRING   ""                    /* bv. "?auth=ID_TOKEN" */
#endif
#ifndef FIREBASE_BEARER_TOKEN
#define FIREBASE_BEARER_TOKEN  ""                    /* niet nodig voor RTDB */
#endif
#ifndef FIREBASE_PUSH_PERIOD_S
#define FIREBASE_PUSH_PERIOD_S 10
#endif

/* ---------- RTC/SNTP config ---------- */
#ifndef NTP_SERVER
#define NTP_SERVER            "pool.ntp.org"
#endif
#ifndef RTC_RESYNC_PERIOD_S
#define RTC_RESYNC_PERIOD_S   3600   /* elk uur resync */
#endif

/* ---------- internals ---------- */
#define HTTP_USER_AGENT       "PSoC6/MTB FirebaseClient"
#define RECV_BUF_LEN          1024

static TaskHandle_t s_client_task = NULL;
static SemaphoreHandle_t s_send_mutex;

/* Zorg dat Wi-Fi verbonden is (met IP) */
static cy_rslt_t ensure_wifi_connected(void)
{
    cy_rslt_t r;
    cy_wcm_ip_address_t ip;

    /* Al IP? */
    r = cy_wcm_get_ip_addr(CY_WCM_INTERFACE_TYPE_STA, &ip, 1);
    if (r == CY_RSLT_SUCCESS) return CY_RSLT_SUCCESS;

    /* Anders verbinden met credentials */
    cy_wcm_connect_params_t cp;
    memset(&cp, 0, sizeof(cp));
    strncpy((char*)cp.ap_credentials.SSID, WIFI_SSID, sizeof(cp.ap_credentials.SSID) - 1);
    strncpy((char*)cp.ap_credentials.password, WIFI_PASSWORD, sizeof(cp.ap_credentials.password) - 1);
    cp.ap_credentials.security = WIFI_SECURITY_TYPE;

    for (int tries = 0; tries < MAX_WIFI_RETRY_COUNT; ++tries)
    {
        r = cy_wcm_connect_ap(&cp, &ip);
        if (r == CY_RSLT_SUCCESS)
        {
            /* Wacht kort tot DHCP/IP klaar is (event zet LED en vlag).
               We pollen even maximaal ~3s zodat we weten of we al 'ready' zijn. */
            for (int t = 0; t < 30 && !s_wifi_ready; ++t) {
                vTaskDelay(pdMS_TO_TICKS(100));
            }

            uint32_t a = ip.ip.v4; /* NB: mogelijk nog 0.0.0.0 als DHCP nog bezig is */
            APP_INFO(("Wi-Fi connected, IP(raw): %lu.%lu.%lu.%lu, ready=%d\n",
                     (a) & 0xFF, (a >> 8) & 0xFF, (a >> 16) & 0xFF, (a >> 24) & 0xFF, (int)s_wifi_ready));

            return CY_RSLT_SUCCESS;
        }
        vTaskDelay(pdMS_TO_TICKS(1500));
    }

    s_wifi_ready = false;
    led_status_set_connected(false);  /* Rood bij hard fail */
    ERR_INFO(("Wi-Fi connect failed: 0x%08lx\n", (unsigned long)r));
    return r;
}

/* HTTPS POST met JSON-body.
 * LET OP: cy_socket_init() en CA-load gebeuren buiten deze functie. */
static cy_rslt_t https_post_json(const char *host, uint16_t port,
                                 const char *path_and_query,
                                 const char *json, size_t json_len,
                                 const char *bearer_token_opt)
{
    cy_rslt_t r;
    cy_socket_t sock = CY_SOCKET_INVALID_HANDLE;

    /* DNS */
    cy_socket_ip_address_t ip;
    memset(&ip, 0, sizeof ip);
    r = cy_socket_gethostbyname(host, CY_SOCKET_IP_VER_V4, &ip);
    if (r != CY_RSLT_SUCCESS) {
        ERR_INFO(("DNS failed: 0x%08lx (host=%s)\n", (unsigned long)r, host));
        return r;
    }

    /* TLS socket */
    r = cy_socket_create(CY_SOCKET_DOMAIN_AF_INET, CY_SOCKET_TYPE_STREAM, CY_SOCKET_IPPROTO_TLS, &sock);
    if (r != CY_RSLT_SUCCESS) {
        ERR_INFO(("socket create failed: 0x%08lx\n", (unsigned long)r));
        return r;
    }

    /* TLS opties: SNI + verify required */
#if defined(CY_SOCKET_SO_TLS_SNI_HOSTNAME)
    r = cy_socket_setsockopt(sock, CY_SOCKET_SOL_TLS, CY_SOCKET_SO_TLS_SNI_HOSTNAME, host, strlen(host));
    if (r != CY_RSLT_SUCCESS) { ERR_INFO(("set SNI failed\n")); goto done; }
#elif defined(CY_SOCKET_SO_TLS_SERVER_NAME)
    r = cy_socket_setsockopt(sock, CY_SOCKET_SOL_TLS, CY_SOCKET_SO_TLS_SERVER_NAME, host, strlen(host));
    if (r != CY_RSLT_SUCCESS) { ERR_INFO(("set TLS ServerName failed\n")); goto done; }
#endif
    {
        uint32_t authmode = CY_SOCKET_TLS_VERIFY_REQUIRED;
        r = cy_socket_setsockopt(sock, CY_SOCKET_SOL_TLS, CY_SOCKET_SO_TLS_AUTH_MODE, &authmode, sizeof(authmode));
        if (r != CY_RSLT_SUCCESS) { ERR_INFO(("auth mode set failed\n")); goto done; }
    }

    /* Connect */
    cy_socket_sockaddr_t sa;
    memset(&sa, 0, sizeof sa);
    sa.ip_address = ip;
    sa.port = port;
    r = cy_socket_connect(sock, &sa, sizeof sa);
    if (r != CY_RSLT_SUCCESS) {
        ERR_INFO(("connect failed: 0x%08lx\n", (unsigned long)r));
        goto done;
    }

    /* HTTP/1.1 POST */
    char hdr[512];
    int hdrlen = snprintf(hdr, sizeof(hdr),
                          "POST %s HTTP/1.1\r\n"
                          "Host: %s\r\n"
                          "User-Agent: %s\r\n"
                          "Content-Type: application/json\r\n"
                          "Content-Length: %lu\r\n"
                          "%s%s%s"
                          "Connection: close\r\n"
                          "\r\n",
                          path_and_query,
                          host,
                          HTTP_USER_AGENT,
                          (unsigned long)json_len,
                          (bearer_token_opt && bearer_token_opt[0]) ? "Authorization: Bearer " : "",
                          (bearer_token_opt && bearer_token_opt[0]) ? bearer_token_opt : "",
                          (bearer_token_opt && bearer_token_opt[0]) ? "\r\n" : "");
    if (hdrlen <= 0 || hdrlen >= (int)sizeof(hdr)) {
        ERR_INFO(("header build overflow\n"));
        r = CY_RSLT_TYPE_ERROR;
        goto done;
    }

    uint32_t sent = 0;
    r = cy_socket_send(sock, hdr, (uint32_t)hdrlen, CY_SOCKET_FLAGS_NONE, &sent);
    if (r != CY_RSLT_SUCCESS || sent != (uint32_t)hdrlen) {
        ERR_INFO(("send header failed: 0x%08lx (sent=%lu)\n", (unsigned long)r, (unsigned long)sent));
        goto done;
    }
    r = cy_socket_send(sock, json, (uint32_t)json_len, CY_SOCKET_FLAGS_NONE, &sent);
    if (r != CY_RSLT_SUCCESS || sent != (uint32_t)json_len) {
        ERR_INFO(("send body failed: 0x%08lx (sent=%lu)\n", (unsigned long)r, (unsigned long)sent));
        goto done;
    }

    /* Response dumpen (opt.) */
    char buf[RECV_BUF_LEN];
    uint32_t recvd;
    do {
        r = cy_socket_recv(sock, buf, sizeof(buf) - 1, CY_SOCKET_FLAGS_NONE, &recvd);
        if (r == CY_RSLT_SUCCESS && recvd > 0) {
            buf[recvd] = '\0';
            APP_INFO(("%s", buf));
        }
    } while (r == CY_RSLT_SUCCESS && recvd > 0);

    r = CY_RSLT_SUCCESS;

done:
    if (sock != CY_SOCKET_INVALID_HANDLE) {
        cy_socket_disconnect(sock, 0);
        cy_socket_delete(sock);
    }
    return r;
}

/* Publieke API: thread-safe one-shot send. */
cy_rslt_t firebase_send_json(const char *json, size_t len)
{
    if (!json || len == 0) return CY_RSLT_TYPE_ERROR;
    if (s_send_mutex == NULL) return CY_RSLT_TYPE_ERROR;

    cy_rslt_t r = ensure_wifi_connected();
    if (r != CY_RSLT_SUCCESS) return r;

    xSemaphoreTake(s_send_mutex, portMAX_DELAY);

    char pathq[256];
    if (FIREBASE_QUERYSTRING[0])
        snprintf(pathq, sizeof pathq, "%s%s", FIREBASE_PATH, FIREBASE_QUERYSTRING);
    else
        snprintf(pathq, sizeof pathq, "%s", FIREBASE_PATH);

    r = https_post_json(FIREBASE_HOST, FIREBASE_PORT, pathq, json, len, FIREBASE_BEARER_TOKEN);

    xSemaphoreGive(s_send_mutex);
    return r;
}

/* Taak: periodiek JSON pushen incl. BMI160 + RTC */
static void firebase_task(void *arg)
{
    (void)arg;
    printf("firebase_task: started\r\n");

    /* LED init + beginstatus (rood als nog geen IP) */
    led_status_init();
    led_status_set_connected(false);

    /* WCM events registreren vóór we gaan connecten (1 arg in v2.3.0) */
    (void)cy_wcm_register_event_callback(wcm_event_cb);

    /* Secure sockets init (1×) */
    cy_rslt_t r = cy_socket_init();
    if (r != CY_RSLT_SUCCESS) {
        ERR_INFO(("Secure sockets init failed: 0x%08lx\n", (unsigned long)r));
        vTaskDelete(NULL);
        return;
    }

    /* TLS Root CA 1× */
    cy_rslt_t r2 = tls_ca_init_once();
    if (r2 != CY_RSLT_SUCCESS) {
        ERR_INFO(("CA load failed: 0x%08lx\n", (unsigned long)r2));
        vTaskDelete(NULL);
        return;
    }

    /* RTC init + (optioneel) SNTP sync zodra Wi-Fi up is */
    rtc_time_init();

    if (!rtc_time_is_set()) {
        if (ensure_wifi_connected() == CY_RSLT_SUCCESS) {
            cy_rslt_t tr = rtc_time_sync_sntp(NTP_SERVER, 5000); // 5s max
            if (tr != CY_RSLT_SUCCESS) {
                ERR_INFO(("SNTP sync failed: 0x%08lx\n", (unsigned long)tr));
            }
        }
    }

    TickType_t last_resync = xTaskGetTickCount();

    /* BMI160 init (niet fatal bij fout) */
    bool imu_ok = (bmi160_init() == CY_RSLT_SUCCESS);
    if (!imu_ok) {
        ERR_INFO(("BMI160 init failed; ga door zonder IMU data\n"));
    }

    static int counter = 0;

    for (;;)
    {
        counter++;

        /* Safeguard: LED 1× per cyclus gelijk trekken met vlag. */
        led_status_set_connected(wifi_is_up());

        /* Periodieke SNTP resync */
        if ((xTaskGetTickCount() - last_resync) >= pdMS_TO_TICKS(RTC_RESYNC_PERIOD_S * 1000UL)) {
            if (ensure_wifi_connected() == CY_RSLT_SUCCESS) {
                cy_rslt_t tr = rtc_time_sync_sntp(NTP_SERVER, 2000);
                if (tr == CY_RSLT_SUCCESS) last_resync = xTaskGetTickCount();
            }
        }

        /* Data opbouwen */
        char json[360];
        uint32_t epoch = rtc_time_get_epoch();

        /* Alleen lokale ISO 8601 met CET/CEST offset */
        char iso_local[32];
        rtc_time_format_iso8601_local(iso_local, epoch);

        if (imu_ok) {
            bmi160_sample_t s;
            if (bmi160_read(&s) == CY_RSLT_SUCCESS) {
                snprintf(json, sizeof json,
                         "{\"device\":\"psoc6\",\"counter\":%d,"
                         "\"ts\":%lu,\"ts_iso\":\"%s\","
                         "\"imu\":{\"ax\":%.3f,\"ay\":%.3f,\"az\":%.3f,"
                         "\"gx\":%.1f,\"gy\":%.1f,\"gz\":%.1f}}",
                         counter, (unsigned long)epoch, iso_local,
                         s.ax, s.ay, s.az, s.gx, s.gy, s.gz);
            } else {
                snprintf(json, sizeof json,
                         "{\"device\":\"psoc6\",\"counter\":%d,"
                         "\"ts\":%lu,\"ts_iso\":\"%s\",\"imu\":\"read_error\"}",
                         counter, (unsigned long)epoch, iso_local);
            }
        } else {
            snprintf(json, sizeof json,
                     "{\"device\":\"psoc6\",\"counter\":%d,"
                     "\"ts\":%lu,\"ts_iso\":\"%s\",\"imu\":\"not_initialized\"}",
                     counter, (unsigned long)epoch, iso_local);
        }

        /* Debug: waar posten we heen? */
        printf("\x1b[2J\x1b[H"); /* clear screen */
        printf("firebase: POST https://%s%s%s\r\n",
               FIREBASE_HOST, FIREBASE_PATH, FIREBASE_QUERYSTRING);

        /* Versturen */
        cy_rslt_t rr = firebase_send_json(json, strlen(json));
        if (rr != CY_RSLT_SUCCESS) {
            ERR_INFO(("firebase_send_json failed: 0x%08lx\n", (unsigned long)rr));
        }

        vTaskDelay(pdMS_TO_TICKS(FIREBASE_PUSH_PERIOD_S * 1000UL));
    }
}

cy_rslt_t firebase_client_start(void)
{
    if (s_client_task) return CY_RSLT_SUCCESS;

    if (s_send_mutex == NULL) {
        s_send_mutex = xSemaphoreCreateMutex();
        if (s_send_mutex == NULL) {
            ERR_INFO(("failed to create mutex\n"));
            return CY_RSLT_TYPE_ERROR;
        }
    }

    printf("firebase_client_start: creating task...\r\n");
    /* Ruime stack ivm TLS */
    BaseType_t ok = xTaskCreate(firebase_task, "firebase", 6 * 1024, NULL,
                                tskIDLE_PRIORITY + 2, &s_client_task);
    printf("firebase_client_start: xTaskCreate returned %ld\r\n", (long)ok);
    return ok == pdPASS ? CY_RSLT_SUCCESS : CY_RSLT_TYPE_ERROR;
}
