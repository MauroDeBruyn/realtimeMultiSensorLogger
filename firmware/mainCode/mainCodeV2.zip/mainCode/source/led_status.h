// source/led_status/led_status.h
#pragma once
#include <stdbool.h>
#include "cyhal_gpio.h"
#include "cybsp.h"

/* Je kunt deze twee pins ook via -DLED_PIN_GREEN=... en -DLED_PIN_RED=... overriden. */
#ifndef LED_PIN_GREEN
  #ifdef CYBSP_LED_RGB_GREEN
    #define LED_PIN_GREEN CYBSP_LED_RGB_GREEN
  #else
    #define LED_PIN_GREEN CYBSP_USER_LED       /* fallback: enkelkleurig */
  #endif
#endif

#ifndef LED_PIN_RED
  #ifdef CYBSP_LED_RGB_RED
    #define LED_PIN_RED   CYBSP_LED_RGB_RED
  #else
    #define LED_PIN_RED   CYBSP_USER_LED2      /* of een vrije GPIO */
  #endif
#endif

#ifdef __cplusplus
extern "C" {
#endif

void led_status_init(void);
void led_status_set_connected(bool connected);

#ifdef __cplusplus
}
#endif
