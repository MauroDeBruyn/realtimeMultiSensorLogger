#include "sensor_bmi160.h"
#include "cyhal.h"
#include "cybsp.h"
#include <stdio.h>
#include <string.h>

/* ---- BMI160 registers/commando's ---- */
#define REG_CHIP_ID         0x00   /* verwacht 0xD1 */
#define REG_CMD             0x7E
#define CMD_SOFTRESET       0xB6
#define CMD_ACC_NORMAL      0x11
#define CMD_GYR_NORMAL      0x15
#define REG_ACC_RANGE       0x41   /* 0x03 = ±2g */
#define REG_GYR_RANGE       0x43   /* 0x00 = ±2000 dps */
#define REG_GYR_DATA        0x0C   /* gx_l..gz_h (6 bytes) */
#define REG_ACC_DATA        0x12   /* ax_l..az_h (6 bytes) */

/* Schaal (bij ±2g en ±2000 dps) */
#define ACC_LSB_PER_G       16384.0f
#define GYR_LSB_PER_DPS     16.4f

static cyhal_i2c_t s_i2c;
static bool s_inited = false;

/* --- I2C helpers --- */
static cy_rslt_t i2c_write_u8(uint8_t dev, uint8_t reg, uint8_t val)
{
    uint8_t b[2] = {reg, val};
    return cyhal_i2c_master_write(&s_i2c, dev, b, 2, 0, true);
}

static cy_rslt_t i2c_read(uint8_t dev, uint8_t reg, uint8_t *buf, size_t len)
{
    cy_rslt_t r = cyhal_i2c_master_write(&s_i2c, dev, &reg, 1, 0, false);
    if (r != CY_RSLT_SUCCESS) return r;
    return cyhal_i2c_master_read(&s_i2c, dev, buf, len, 0, true);
}

/* --- API --- */
cy_rslt_t bmi160_init(void)
{
    if (s_inited) return CY_RSLT_SUCCESS;

    cy_rslt_t r;
    cyhal_i2c_cfg_t cfg = {
        .is_slave = false,
        .address = 0,
        .frequencyhal_hz = 100000  /* begin op 100 kHz; BMI160 kan ook 400 kHz */
    };

    r = cyhal_i2c_init(&s_i2c, BMI160_I2C_SDA_PIN, BMI160_I2C_SCL_PIN, NULL);
    if (r != CY_RSLT_SUCCESS) {
        printf("BMI160: I2C init fail 0x%08lX\r\n", (unsigned long)r);
        return r;
    }
    r = cyhal_i2c_configure(&s_i2c, &cfg);
    if (r != CY_RSLT_SUCCESS) {
        printf("BMI160: I2C cfg fail 0x%08lX\r\n", (unsigned long)r);
        return r;
    }

    /* Check CHIP_ID */
    uint8_t id = 0;
    r = i2c_read(BMI160_I2C_ADDR, REG_CHIP_ID, &id, 1);
    if (r != CY_RSLT_SUCCESS) {
        printf("BMI160: CHIP_ID read fail 0x%08lX\r\n", (unsigned long)r);
        return r;
    }
    if (id != 0xD1) {
        printf("BMI160: unexpected CHIP_ID 0x%02X (exp 0xD1)\r\n", id);
        /* Niet fatal; ga toch door, maar print waarschuwing */
    }

    /* Soft reset */
    i2c_write_u8(BMI160_I2C_ADDR, REG_CMD, CMD_SOFTRESET);
    cyhal_system_delay_ms(100);

    /* Power modes */
    i2c_write_u8(BMI160_I2C_ADDR, REG_CMD, CMD_ACC_NORMAL);
    cyhal_system_delay_ms(5);
    i2c_write_u8(BMI160_I2C_ADDR, REG_CMD, CMD_GYR_NORMAL);
    cyhal_system_delay_ms(80);

    /* Ranges */
    i2c_write_u8(BMI160_I2C_ADDR, REG_ACC_RANGE, 0x03); /* ±2g */
    i2c_write_u8(BMI160_I2C_ADDR, REG_GYR_RANGE, 0x00); /* ±2000 dps */

    s_inited = true;
    printf("BMI160: init OK (±2g, ±2000 dps)\r\n");
    return CY_RSLT_SUCCESS;
}

cy_rslt_t bmi160_read(bmi160_sample_t *out)
{
    if (!s_inited) {
        cy_rslt_t r = bmi160_init();
        if (r != CY_RSLT_SUCCESS) return r;
    }
    uint8_t ga[6], aa[6];
    cy_rslt_t r;

    r = i2c_read(BMI160_I2C_ADDR, REG_GYR_DATA, ga, 6);
    if (r != CY_RSLT_SUCCESS) return r;

    r = i2c_read(BMI160_I2C_ADDR, REG_ACC_DATA, aa, 6);
    if (r != CY_RSLT_SUCCESS) return r;

    int16_t gx = (int16_t)((ga[1]<<8) | ga[0]);
    int16_t gy = (int16_t)((ga[3]<<8) | ga[2]);
    int16_t gz = (int16_t)((ga[5]<<8) | ga[4]);

    int16_t ax = (int16_t)((aa[1]<<8) | aa[0]);
    int16_t ay = (int16_t)((aa[3]<<8) | aa[2]);
    int16_t az = (int16_t)((aa[5]<<8) | aa[4]);

    out->ax = (float)ax / ACC_LSB_PER_G;
    out->ay = (float)ay / ACC_LSB_PER_G;
    out->az = (float)az / ACC_LSB_PER_G;
    out->gx = (float)gx / GYR_LSB_PER_DPS;
    out->gy = (float)gy / GYR_LSB_PER_DPS;
    out->gz = (float)gz / GYR_LSB_PER_DPS;

    return CY_RSLT_SUCCESS;
}

void bmi160_to_json(char *dst, size_t dst_len, const bmi160_sample_t *s)
{
    /* Compact JSON die je zo naar Firebase kunt pushen */
    snprintf(dst, dst_len,
             "{\"imu\":{\"ax\":%.3f,\"ay\":%.3f,\"az\":%.3f,"
             "\"gx\":%.1f,\"gy\":%.1f,\"gz\":%.1f}}",
             s->ax, s->ay, s->az, s->gx, s->gy, s->gz);
}
