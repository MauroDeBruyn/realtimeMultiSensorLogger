/*
 * rtc_time.c
 * Eenvoudige RTC met one-shot NTP (UDP) via cy_secure_sockets.
 * - Geen lwIP SNTP dependency.
 * - Houdt epoch bij met FreeRTOS ticks.
 * - Format UTC ISO-8601 ("Z") en lokale CET/CEST ISO-8601 ("+01:00"/"+02:00").
 */

#include "rtc_time.h"

#include "cy_secure_sockets.h"
#include "cy_result.h"
#include "cy_retarget_io.h"

#include <stdint.h>
#include <stdbool.h>
#include <string.h>
#include <stdio.h>
#include <time.h>

#include <FreeRTOS.h>
#include <task.h>

/* ====== interne state ====== */
static uint32_t   s_base_epoch = 0;      /* UNIX epoch (s) bij set */
static TickType_t s_base_ticks = 0;      /* FreeRTOS ticks bij set */
static bool       s_time_valid = false;

/* NTP constants */
#define NTP_PORT                123
#define NTP_PACKET_LEN          48
#define NTP_TO_UNIX_EPOCH       2208988800UL  /* seconds from 1900->1970 */

/* ====== helpers ====== */

static uint32_t be32_read(const uint8_t *p)
{
    return ((uint32_t)p[0] << 24) |
           ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8)  |
           ((uint32_t)p[3]);
}

/* Zeller (gregoriaans): 0=Sunday..6=Saturday */
static int dow_ymd(int year, int month, int day)
{
    /* Zeller gebruikt m: Mar=3..Jan=13, Feb=14 */
    if (month < 3) { month += 12; year -= 1; }
    int K = year % 100;
    int J = year / 100;
    int h = (day + (13*(month + 1))/5 + K + (K/4) + (J/4) + 5*J) % 7;
    /* h: 0=Saturday,1=Sunday,... -> 1->0 (Sunday), 2->1 (Mon), ... */
    int dow = (h + 6) % 7;
    return dow; /* 0=Sunday .. 6=Saturday */
}

/* CET/CEST offset in minuten voor gegeven UTC-tijd.
 * Regels: DST start laatste zondag in maart 01:00 UTC, eindigt laatste zondag in oktober 01:00 UTC.
 * Retourneert 60 (CET) of 120 (CEST).
 */
static int europe_cet_cest_offset_minutes(const struct tm *utc_tm)
{
    int Y = utc_tm->tm_year + 1900;
    int M = utc_tm->tm_mon + 1;
    int D = utc_tm->tm_mday;
    int H = utc_tm->tm_hour;

    if (M < 3 || M > 10) return 60;      /* jan-feb & nov-dec: CET */
    if (M > 3 && M < 10) return 120;     /* apr-sep: CEST */

    /* laatste zondag van maart/oktober (dag-nummer) */
    int w_march31 = dow_ymd(Y, 3, 31);   /* 0=zon ... */
    int last_sun_march = 31 - w_march31; /* 31 minus weekday->laatste zondag */
    int w_oct31 = dow_ymd(Y, 10, 31);
    int last_sun_october = 31 - w_oct31;

    if (M == 3) {
        if (D > last_sun_march) return 120;
        if (D < last_sun_march) return 60;
        /* D == last_sun_march */
        return (H >= 1) ? 120 : 60; /* switch 01:00 UTC */
    } else { /* M == 10 */
        if (D > last_sun_october) return 60;
        if (D < last_sun_october) return 120;
        /* D == last_sun_october */
        return (H >= 1) ? 60 : 120; /* switch 01:00 UTC */
    }
}

/* ====== public API ====== */

void rtc_time_init(void)
{
    s_base_epoch = 0;
    s_base_ticks = xTaskGetTickCount();
    s_time_valid = false;
}

bool rtc_time_is_set(void)
{
    return s_time_valid;
}

void rtc_time_set_epoch(uint32_t epoch)
{
    s_base_epoch = epoch;
    s_base_ticks = xTaskGetTickCount();
    s_time_valid = true;
}

uint32_t rtc_time_get_epoch(void)
{
    TickType_t now = xTaskGetTickCount();
    uint32_t elapsed_ms = (uint32_t)((now - s_base_ticks) * portTICK_PERIOD_MS);
    return s_base_epoch + (elapsed_ms / 1000UL);
}

/* UTC ISO8601 "YYYY-MM-DDTHH:MM:SSZ" */
void rtc_time_format_iso8601(char *buf, uint32_t epoch)
{
    if (buf == NULL) return;
    time_t t = (time_t)epoch;
    struct tm tm_utc;

#if defined(_POSIX_THREAD_SAFE_FUNCTIONS) || defined(__NEWLIB__)
    gmtime_r(&t, &tm_utc);
#else
    struct tm *ptm = gmtime(&t);
    if (ptm) tm_utc = *ptm; else memset(&tm_utc, 0, sizeof tm_utc);
#endif

    snprintf(buf, 25, "%04d-%02d-%02dT%02d:%02d:%02dZ",
             tm_utc.tm_year + 1900, tm_utc.tm_mon + 1, tm_utc.tm_mday,
             tm_utc.tm_hour, tm_utc.tm_min, tm_utc.tm_sec);
}

/* Lokale CET/CEST ISO8601 "YYYY-MM-DDTHH:MM:SS+01:00/+02:00" */
void rtc_time_format_iso8601_local(char *buf, uint32_t epoch)
{
    if (buf == NULL) return;

    /* 1) breek UTC op */
    time_t t = (time_t)epoch;
    struct tm tm_utc;

#if defined(_POSIX_THREAD_SAFE_FUNCTIONS) || defined(__NEWLIB__)
    gmtime_r(&t, &tm_utc);
#else
    struct tm *ptm = gmtime(&t);
    if (ptm) tm_utc = *ptm; else memset(&tm_utc, 0, sizeof tm_utc);
#endif

    /* 2) bereken CET/CEST offset en pas toe op epoch */
    int offset_min = europe_cet_cest_offset_minutes(&tm_utc);
    int32_t adj_epoch = (int32_t)epoch + (offset_min * 60);

    time_t tl = (time_t)adj_epoch;
    struct tm tm_local;
#if defined(_POSIX_THREAD_SAFE_FUNCTIONS) || defined(__NEWLIB__)
    gmtime_r(&tl, &tm_local);
#else
    struct tm *pl = gmtime(&tl);
    if (pl) tm_local = *pl; else memset(&tm_local, 0, sizeof tm_local);
#endif

    /* 3) format met expliciete offset ±HH:MM */
    int oh = offset_min / 60;
    int om = (offset_min < 0 ? -offset_min : offset_min) % 60;
    char sign = (offset_min >= 0) ? '+' : '-';

    snprintf(buf, 30, "%04d-%02d-%02dT%02d:%02d:%02d%c%02d:%02d",
             tm_local.tm_year + 1900, tm_local.tm_mon + 1, tm_local.tm_mday,
             tm_local.tm_hour, tm_local.tm_min, tm_local.tm_sec,
             sign, (oh >= 0 ? oh : -oh), om);
}

/* Geef de lokale offset (CET/CEST) in minuten terug (60 of 120) voor loggen. */
int rtc_time_local_offset_minutes(uint32_t epoch)
{
    time_t t = (time_t)epoch;
    struct tm tm_utc;

#if defined(_POSIX_THREAD_SAFE_FUNCTIONS) || defined(__NEWLIB__)
    gmtime_r(&t, &tm_utc);
#else
    struct tm *ptm = gmtime(&t);
    if (ptm) tm_utc = *ptm; else memset(&tm_utc, 0, sizeof tm_utc);
#endif

    return europe_cet_cest_offset_minutes(&tm_utc);
}

/* One-shot NTP (UDP) naar 'server'; timeout_ms = receive-timeout. */
cy_rslt_t rtc_time_sync_sntp(const char *server, uint32_t timeout_ms)
{
    if (server == NULL || server[0] == '\0') {
        return CY_RSLT_TYPE_ERROR;
    }

    cy_rslt_t r;
    cy_socket_t sock = CY_SOCKET_INVALID_HANDLE;

    /* DNS lookup */
    cy_socket_ip_address_t ip;
    memset(&ip, 0, sizeof ip);
    r = cy_socket_gethostbyname(server, CY_SOCKET_IP_VER_V4, &ip);
    if (r != CY_RSLT_SUCCESS) {
        printf("SNTP: DNS failed 0x%08lx for %s\r\n", (unsigned long)r, server);
        return r;
    }

    /* UDP socket */
    r = cy_socket_create(CY_SOCKET_DOMAIN_AF_INET, CY_SOCKET_TYPE_DGRAM, CY_SOCKET_IPPROTO_UDP, &sock);
    if (r != CY_RSLT_SUCCESS) {
        printf("SNTP: socket create failed 0x%08lx\r\n", (unsigned long)r);
        return r;
    }

    /* receive timeout */
    uint32_t rcv_to = timeout_ms;
    (void) cy_socket_setsockopt(sock, CY_SOCKET_SOL_SOCKET, CY_SOCKET_SO_RCVTIMEO, &rcv_to, sizeof(rcv_to));

    /* NTP packet (48 bytes). LI=0, VN=4, Mode=3 (client). 0x1B. */
    uint8_t pkt[NTP_PACKET_LEN] = {0};
    pkt[0] = 0x1B;

    /* bestemmingsadres */
    cy_socket_sockaddr_t sa;
    memset(&sa, 0, sizeof sa);
    sa.ip_address = ip;
    sa.port = NTP_PORT;

    /* verstuur */
    uint32_t sent = 0;
    r = cy_socket_sendto(sock, pkt, sizeof pkt, CY_SOCKET_FLAGS_NONE, &sa, sizeof sa, &sent);
    if (r != CY_RSLT_SUCCESS || sent != sizeof pkt) {
        printf("SNTP: sendto failed 0x%08lx (sent=%lu)\r\n", (unsigned long)r, (unsigned long)sent);
        cy_socket_delete(sock);
        return r == CY_RSLT_SUCCESS ? CY_RSLT_TYPE_ERROR : r;
    }

    /* ontvang */
    uint8_t rsp[128];
    uint32_t recvd = 0;
    cy_socket_sockaddr_t from;
    uint32_t fromlen = sizeof from;
    r = cy_socket_recvfrom(sock, rsp, sizeof rsp, CY_SOCKET_FLAGS_NONE, &from, &fromlen, &recvd);

    /* socket opruimen */
    cy_socket_delete(sock);

    if (r != CY_RSLT_SUCCESS || recvd < NTP_PACKET_LEN) {
        printf("SNTP: recvfrom failed 0x%08lx (recvd=%lu)\r\n", (unsigned long)r, (unsigned long)recvd);
        return r == CY_RSLT_SUCCESS ? CY_RSLT_TYPE_ERROR : r;
    }

    /* Transmit Timestamp (secs) @ 40..43 (big endian) */
    uint32_t ntp_secs = be32_read(&rsp[40]);
    if (ntp_secs < NTP_TO_UNIX_EPOCH) {
        return CY_RSLT_TYPE_ERROR; /* onzinnig antwoord */
    }

    uint32_t unix_epoch = ntp_secs - NTP_TO_UNIX_EPOCH;
    rtc_time_set_epoch(unix_epoch);
    return CY_RSLT_SUCCESS;
}
